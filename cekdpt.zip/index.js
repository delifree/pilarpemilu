const fs = require('fs');
const puppeteer = require('puppeteer');

const bukaBrowser = async (nikInput) => {
  const browser = await puppeteer.launch({
    headless: "new",
    defaultViewport: false,
  });
  const page = await browser.newPage();

  try {
    await page.goto('https://cekdptonline.kpu.go.id/');

    await page.waitForSelector('#__BVID__22');
    await page.type('#__BVID__22', nikInput);

    // Klik tombol "Pencarian"
    await page.click('button.btn:nth-child(2)');

    // Menunggu hingga data muncul di halaman
    await page.waitForSelector('.list-item-heading');

    // Mengambil dan menyimpan data dari halaman ke dalam array
    const namaElement = await page.$('.list-item-heading + p:nth-child(3)');
    const tpsElement = await page.$('.list-item-heading + p:nth-child(12)');

    const nik = nikInput
    const nama = await page.evaluate(el => el.textContent, namaElement);
    const tps = await page.evaluate(el => el.textContent, tpsElement);

    const data = [nik, nama, tps];

    // Menyimpan data dalam file JSON
    const jsonData = JSON.stringify(data, null, 2);
    fs.writeFileSync('data.json', jsonData, 'utf8');
    
    console.log('Data berhasil disimpan dalam file data.json');

    // ... lanjutkan dengan kode lainnya sesuai kebutuhan Anda ...

  } catch (error) {
    console.error('Terjadi kesalahan:', error);
  } finally {
    console.log('Tutup browser');
    await browser.close();
  }
};

const nikInput = process.argv[2] || ''; // Ambil nilai NIK dari argumen
bukaBrowser(nikInput);
